import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import fs from "fs";
import multer from "multer";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("database.db");
const JWT_SECRET = process.env.JWT_SECRET || "npd-tracker-secret-key-123";

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE,
    password_hash TEXT,
    name TEXT,
    role TEXT CHECK(role IN ('ADMIN', 'PMO', 'PL'))
  );

  CREATE TABLE IF NOT EXISTS stages_template (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    stage_number INTEGER UNIQUE,
    stage_name TEXT,
    checklist_json TEXT
  );

  CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    pl_id INTEGER,
    current_stage INTEGER DEFAULT 1,
    status TEXT CHECK(status IN ('PENDING_PMO', 'ACTIVE', 'SUBMITTED', 'COMPLETED')),
    FOREIGN KEY(pl_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS project_task_data (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER,
    stage_num INTEGER,
    task_id TEXT,
    status TEXT CHECK(status IN ('NOT_STARTED', 'STARTED', 'IN_TRANSIT', 'DONE')),
    remarks TEXT,
    alert_date TEXT,
    alert_comment TEXT,
    FOREIGN KEY(project_id) REFERENCES projects(id)
  );

  CREATE TABLE IF NOT EXISTS documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER,
    stage_num INTEGER,
    task_id TEXT,
    file_path TEXT,
    uploaded_by INTEGER,
    FOREIGN KEY(project_id) REFERENCES projects(id),
    FOREIGN KEY(uploaded_by) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    action TEXT,
    details TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    reversible_flag BOOLEAN DEFAULT 0,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );
`);

// Migrations for existing databases
try {
  db.exec("ALTER TABLE documents ADD COLUMN task_id TEXT");
} catch (e) {}

try {
  db.exec("ALTER TABLE project_task_data ADD COLUMN alert_comment TEXT");
} catch (e) {}

// Seed Admin if not exists
const adminUser = db.prepare("SELECT * FROM users WHERE email = 'admin@example.com'").get();
if (!adminUser) {
  const hash = bcrypt.hashSync("admin123", 10);
  db.prepare("INSERT INTO users (email, password_hash, name, role) VALUES (?, ?, ?, ?)").run(
    "admin@example.com",
    hash,
    "System Admin",
    "ADMIN"
  );
}

// Seed default stages if empty
const stagesCount = db.prepare("SELECT COUNT(*) as count FROM stages_template").get() as { count: number };
if (stagesCount.count === 0) {
  const defaultStages = [
    { num: 1, name: "Concept", tasks: JSON.stringify([{ id: "t1", label: "Market Research" }, { id: "t2", label: "Feasibility Study" }]) },
    { num: 2, name: "Design", tasks: JSON.stringify([{ id: "t3", label: "CAD Models" }, { id: "t4", label: "Prototyping" }]) },
    { num: 3, name: "Development", tasks: JSON.stringify([{ id: "t5", label: "Tooling" }, { id: "t6", label: "Testing" }]) },
    { num: 4, name: "Launch", tasks: JSON.stringify([{ id: "t7", label: "Marketing" }, { id: "t8", label: "Distribution" }]) }
  ];
  const insertStage = db.prepare("INSERT INTO stages_template (stage_number, stage_name, checklist_json) VALUES (?, ?, ?)");
  defaultStages.forEach(s => insertStage.run(s.num, s.name, s.tasks));
}

const app = express();
app.use(express.json());

// File Upload Setup
const uploadDir = path.join(__dirname, "uploads");
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => cb(null, Date.now() + "-" + file.originalname)
});
const upload = multer({ storage });

// Auth Middleware
const authenticate = (req: any, res: any, next: any) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ error: "Unauthorized" });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch (e) {
    res.status(401).json({ error: "Invalid token" });
  }
};

const logAction = (userId: number, action: string, details: string, reversible = false) => {
  db.prepare("INSERT INTO logs (user_id, action, details, reversible_flag) VALUES (?, ?, ?, ?)").run(
    userId,
    action,
    details,
    reversible ? 1 : 0
  );
};

// --- API ROUTES ---

// Auth
app.post("/api/login", (req, res) => {
  const { email, password } = req.body;
  console.log(`Login attempt for: ${email}`);
  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email) as any;
  if (user) {
    if (bcrypt.compareSync(password, user.password_hash)) {
      const token = jwt.sign({ id: user.id, role: user.role, name: user.name }, JWT_SECRET);
      res.json({ token, user: { id: user.id, role: user.role, name: user.name, email: user.email } });
    } else {
      console.log(`Invalid password for: ${email}`);
      res.status(401).json({ error: "Invalid credentials" });
    }
  } else {
    console.log(`User not found: ${email}`);
    res.status(401).json({ error: "Invalid credentials" });
  }
});

// Users (Admin/PMO)
app.get("/api/users", authenticate, (req: any, res) => {
  if (req.user.role !== "ADMIN" && req.user.role !== "PMO") return res.status(403).json({ error: "Forbidden" });
  const users = db.prepare("SELECT id, email, name, role FROM users").all();
  res.json(users);
});

app.post("/api/users", authenticate, (req: any, res) => {
  if (req.user.role !== "ADMIN") return res.status(403).json({ error: "Forbidden" });
  const { email, password, name, role } = req.body;
  const hash = bcrypt.hashSync(password, 10);
  try {
    const result = db.prepare("INSERT INTO users (email, password_hash, name, role) VALUES (?, ?, ?, ?)").run(email, hash, name, role);
    logAction(req.user.id, "CREATE_USER", `Created user ${email} (ID: ${result.lastInsertRowid}) with role ${role}`, true);
    res.json({ id: result.lastInsertRowid });
  } catch (e) {
    res.status(400).json({ error: "User already exists" });
  }
});

app.post("/api/users/bulk", authenticate, (req: any, res) => {
  if (req.user.role !== "ADMIN") return res.status(403).json({ error: "Forbidden" });
  const users = req.body; // Array of { email, password, name, role }
  const insert = db.prepare("INSERT INTO users (email, password_hash, name, role) VALUES (?, ?, ?, ?)");
  
  const results = [];
  const errors = [];

  const transaction = db.transaction((usersList) => {
    for (const user of usersList) {
      try {
        const hash = bcrypt.hashSync(user.password || "user123", 10);
        insert.run(user.email, hash, user.name, user.role);
        results.push(user.email);
      } catch (e) {
        errors.push({ email: user.email, error: (e as Error).message });
      }
    }
  });

  transaction(users);
  logAction(req.user.id, "BULK_CREATE_USERS", `Bulk created ${results.length} users`);
  res.json({ success: true, count: results.length, errors });
});

app.delete("/api/users/:id", authenticate, (req: any, res) => {
  if (req.user.role !== "ADMIN") return res.status(403).json({ error: "Forbidden" });
  
  // Prevent deleting self
  if (parseInt(req.params.id) === req.user.id) {
    return res.status(400).json({ error: "Cannot delete your own account" });
  }

  const result = db.prepare("DELETE FROM users WHERE id = ?").run(req.params.id);
  if (result.changes === 0) return res.status(404).json({ error: "User not found" });
  
  logAction(req.user.id, "DELETE_USER", `Deleted user ID ${req.params.id}`);
  res.json({ success: true });
});

// Stages Template (Admin)
app.get("/api/stages-template", authenticate, (req, res) => {
  const stages = db.prepare("SELECT * FROM stages_template ORDER BY stage_number").all();
  res.json(stages.map((s: any) => ({ ...s, checklist: JSON.parse(s.checklist_json) })));
});

app.put("/api/stages-template/:id", authenticate, (req: any, res) => {
  if (req.user.role !== "ADMIN") return res.status(403).json({ error: "Forbidden" });
  const { stage_name, checklist } = req.body;
  db.prepare("UPDATE stages_template SET stage_name = ?, checklist_json = ? WHERE id = ?").run(
    stage_name,
    JSON.stringify(checklist),
    req.params.id
  );
  logAction(req.user.id, "UPDATE_STAGE", `Updated stage ${req.params.id}`);
  res.json({ success: true });
});

app.post("/api/stages-template", authenticate, (req: any, res) => {
  if (req.user.role !== "ADMIN") return res.status(403).json({ error: "Forbidden" });
  const { stage_name, checklist } = req.body;
  const maxStage = db.prepare("SELECT MAX(stage_number) as max FROM stages_template").get() as any;
  const nextNum = (maxStage.max || 0) + 1;
  
  const result = db.prepare("INSERT INTO stages_template (stage_number, stage_name, checklist_json) VALUES (?, ?, ?)").run(
    nextNum,
    stage_name,
    JSON.stringify(checklist || [])
  );
  logAction(req.user.id, "CREATE_STAGE", `Created stage ${nextNum}: ${stage_name}`);
  res.json({ id: result.lastInsertRowid, stage_number: nextNum });
});

app.post("/api/stages-template/bulk", authenticate, (req: any, res) => {
  if (req.user.role !== "ADMIN") return res.status(403).json({ error: "Forbidden" });
  const stages = req.body; // Array of { stage_name, checklist }
  
  const insert = db.prepare("INSERT INTO stages_template (stage_number, stage_name, checklist_json) VALUES (?, ?, ?)");
  const maxStage = db.prepare("SELECT MAX(stage_number) as max FROM stages_template").get() as any;
  let nextNum = (maxStage.max || 0) + 1;

  const results = [];
  const transaction = db.transaction((stagesList) => {
    for (const stage of stagesList) {
      insert.run(nextNum++, stage.stage_name, JSON.stringify(stage.checklist || []));
      results.push(stage.stage_name);
    }
  });

  transaction(stages);
  logAction(req.user.id, "BULK_CREATE_STAGES", `Bulk created ${results.length} stages`);
  res.json({ success: true, count: results.length });
});

app.delete("/api/stages-template/:id", authenticate, (req: any, res) => {
  if (req.user.role !== "ADMIN") return res.status(403).json({ error: "Forbidden" });
  
  const stage = db.prepare("SELECT stage_number FROM stages_template WHERE id = ?").get(req.params.id) as any;
  if (!stage) return res.status(404).json({ error: "Stage not found" });

  const inUse = db.prepare("SELECT COUNT(*) as count FROM projects WHERE current_stage = ?").get(stage.stage_number) as any;
  if (inUse.count > 0) return res.status(400).json({ error: "Stage is in use by active projects and cannot be deleted" });

  db.prepare("DELETE FROM stages_template WHERE id = ?").run(req.params.id);
  logAction(req.user.id, "DELETE_STAGE", `Deleted stage ${req.params.id}`);
  res.json({ success: true });
});

// Projects
app.get("/api/projects", authenticate, (req: any, res) => {
  let projects;
  if (req.user.role === "PL") {
    projects = db.prepare(`
      SELECT p.*, u.name as pl_name 
      FROM projects p 
      JOIN users u ON p.pl_id = u.id 
      WHERE p.pl_id = ?
    `).all(req.user.id);
  } else {
    projects = db.prepare(`
      SELECT p.*, u.name as pl_name 
      FROM projects p 
      JOIN users u ON p.pl_id = u.id
    `).all();
  }
  res.json(projects);
});

app.post("/api/projects", authenticate, (req: any, res) => {
  if (req.user.role !== "PMO" && req.user.role !== "PL") return res.status(403).json({ error: "Forbidden" });
  const { name, pl_id } = req.body;
  
  // If PL is creating, they must assign to themselves
  const finalPlId = req.user.role === "PL" ? req.user.id : pl_id;
  
  const result = db.prepare("INSERT INTO projects (name, pl_id, status) VALUES (?, ?, 'PENDING_PMO')").run(name, finalPlId);
  logAction(req.user.id, "CREATE_PROJECT", `Created project ${name} (ID: ${result.lastInsertRowid}) assigned to PL ${finalPlId}`, true);
  res.json({ id: result.lastInsertRowid });
});

app.patch("/api/projects/:id/status", authenticate, (req: any, res) => {
  if (req.user.role !== "PMO" && req.user.role !== "PL") return res.status(403).json({ error: "Forbidden" });
  const { status } = req.body;
  
  // PL can only submit for evaluation
  if (req.user.role === "PL" && status !== "SUBMITTED") {
    return res.status(403).json({ error: "PL can only submit for evaluation" });
  }

  db.prepare("UPDATE projects SET status = ? WHERE id = ?").run(status, req.params.id);
  logAction(req.user.id, "UPDATE_PROJECT_STATUS", `Project ${req.params.id} status set to ${status}`);
  res.json({ success: true });
});

// Project Tasks
app.get("/api/projects/:id/tasks", authenticate, (req, res) => {
  const tasks = db.prepare("SELECT * FROM project_task_data WHERE project_id = ?").all(req.params.id);
  res.json(tasks);
});

app.post("/api/projects/:id/tasks", authenticate, (req: any, res) => {
  const { stage_num, task_id, status, remarks, alert_date, alert_comment } = req.body;
  const existing = db.prepare("SELECT id FROM project_task_data WHERE project_id = ? AND stage_num = ? AND task_id = ?").get(req.params.id, stage_num, task_id) as any;
  
  if (existing) {
    db.prepare("UPDATE project_task_data SET status = ?, remarks = ?, alert_date = ?, alert_comment = ? WHERE id = ?").run(status, remarks, alert_date, alert_comment, existing.id);
  } else {
    db.prepare("INSERT INTO project_task_data (project_id, stage_num, task_id, status, remarks, alert_date, alert_comment) VALUES (?, ?, ?, ?, ?, ?, ?)").run(req.params.id, stage_num, task_id, status, remarks, alert_date, alert_comment);
  }
  res.json({ success: true });
});

// Evaluation & Progression
app.post("/api/projects/:id/evaluate", authenticate, (req: any, res) => {
  if (req.user.role !== "PMO") return res.status(403).json({ error: "Forbidden" });
  const { conform } = req.body;
  const project = db.prepare("SELECT * FROM projects WHERE id = ?").get(req.params.id) as any;
  
  if (conform) {
    const nextStage = project.current_stage + 1;
    const maxStage = db.prepare("SELECT MAX(stage_number) as max FROM stages_template").get() as any;
    
    if (nextStage > maxStage.max) {
      db.prepare("UPDATE projects SET status = 'COMPLETED' WHERE id = ?").run(req.params.id);
    } else {
      db.prepare("UPDATE projects SET current_stage = ?, status = 'ACTIVE' WHERE id = ?").run(nextStage, req.params.id);
    }
    logAction(req.user.id, "EVALUATE_CONFORM", `Project ${req.params.id} stage ${project.current_stage} approved`, true);
  } else {
    db.prepare("UPDATE projects SET status = 'ACTIVE' WHERE id = ?").run(req.params.id);
    logAction(req.user.id, "EVALUATE_NON_CONFORM", `Project ${req.params.id} stage ${project.current_stage} rejected`);
  }
  res.json({ success: true });
});

// Documents
app.post("/api/projects/:id/documents", authenticate, upload.single("file"), (req: any, res) => {
  const { stage_num, task_id } = req.body;
  const result = db.prepare("INSERT INTO documents (project_id, stage_num, task_id, file_path, uploaded_by) VALUES (?, ?, ?, ?, ?)").run(
    req.params.id,
    stage_num,
    task_id || null,
    req.file.filename,
    req.user.id
  );
  res.json({ id: result.lastInsertRowid, filename: req.file.filename });
});

app.get("/api/projects/:id/documents", authenticate, (req, res) => {
  const docs = db.prepare("SELECT * FROM documents WHERE project_id = ?").all(req.params.id);
  res.json(docs);
});

app.get("/api/documents/:filename", (req, res) => {
  res.sendFile(path.join(uploadDir, req.params.filename));
});

// Logs
app.get("/api/logs", authenticate, (req: any, res) => {
  if (req.user.role !== "ADMIN") return res.status(403).json({ error: "Forbidden" });
  const logs = db.prepare(`
    SELECT l.*, u.name as user_name 
    FROM logs l 
    JOIN users u ON l.user_id = u.id 
    ORDER BY timestamp DESC
  `).all();
  res.json(logs);
});

app.post("/api/logs/:id/reverse", authenticate, (req: any, res) => {
  if (req.user.role !== "ADMIN") return res.status(403).json({ error: "Forbidden" });
  const log = db.prepare("SELECT * FROM logs WHERE id = ?").get(req.params.id) as any;
  if (!log || !log.reversible_flag) return res.status(400).json({ error: "Not reversible" });
  
  try {
    if (log.action === "EVALUATE_CONFORM") {
      const projectId = log.details.match(/Project (\d+)/)?.[1];
      if (projectId) {
        const project = db.prepare("SELECT * FROM projects WHERE id = ?").get(projectId) as any;
        if (project.status === 'COMPLETED') {
            db.prepare("UPDATE projects SET status = 'SUBMITTED' WHERE id = ?").run(projectId);
        } else {
            db.prepare("UPDATE projects SET current_stage = current_stage - 1, status = 'SUBMITTED' WHERE id = ?").run(projectId);
        }
      }
    } else if (log.action === "CREATE_PROJECT") {
      const projectId = log.details.match(/\(ID: (\d+)\)/)?.[1];
      if (projectId) {
        db.prepare("DELETE FROM projects WHERE id = ?").run(projectId);
        db.prepare("DELETE FROM project_task_data WHERE project_id = ?").run(projectId);
        db.prepare("DELETE FROM documents WHERE project_id = ?").run(projectId);
      }
    } else if (log.action === "CREATE_USER") {
      const userId = log.details.match(/\(ID: (\d+)\)/)?.[1];
      if (userId) {
        db.prepare("DELETE FROM users WHERE id = ?").run(userId);
      }
    } else {
      return res.status(400).json({ error: "Reversal logic not implemented for this action" });
    }

    db.prepare("UPDATE logs SET reversible_flag = 0 WHERE id = ?").run(req.params.id);
    logAction(req.user.id, "REVERSE_LOG", `Reversed log ${req.params.id}: ${log.action}`);
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: "Failed to reverse action: " + (e as Error).message });
  }
});

// Vite middleware for development
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  const PORT = 3000;
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();

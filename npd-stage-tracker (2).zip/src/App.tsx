import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  PlusCircle, 
  Users, 
  Settings, 
  ClipboardList, 
  LogOut, 
  ChevronRight, 
  CheckCircle2, 
  AlertCircle,
  FileText,
  History,
  Check,
  X,
  Upload,
  Download,
  Calendar,
  RefreshCw,
  UserPlus,
  FileSpreadsheet
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { format, isBefore, startOfDay } from 'date-fns';
import * as XLSX from 'xlsx';
import { User, Project, StageTemplate, TaskData, Log, Document as DocType } from './types';

// --- API Helpers ---
const API_URL = '/api';

const fetchWithAuth = async (url: string, options: any = {}) => {
  const token = localStorage.getItem('token');
  const res = await fetch(url, {
    ...options,
    headers: {
      ...options.headers,
      'Authorization': `Bearer ${token}`,
      'Content-Type': options.body instanceof FormData ? undefined : 'application/json',
    },
  });
  if (res.status === 401) {
    localStorage.removeItem('token');
    window.location.reload();
  }
  return res;
};

// --- Components ---

const Login = ({ onLogin }: { onLogin: (user: User, token: string) => void }) => {
  const [email, setEmail] = useState('admin@example.com');
  const [password, setPassword] = useState('admin123');
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      const res = await fetch(`${API_URL}/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (res.ok && data.token) {
        onLogin(data.user, data.token);
      } else {
        setError(data.error || 'Invalid credentials');
      }
    } catch (err) {
      setError('Server connection failed. Please try again.');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white p-8 rounded-3xl shadow-xl w-full max-w-md border border-black/5"
      >
        <div className="flex justify-center mb-6">
          <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-indigo-600/20">
            <ClipboardList size={32} />
          </div>
        </div>
        <h1 className="text-3xl font-serif font-medium text-center mb-2 text-slate-900">NPD Tracker</h1>
        <p className="text-slate-500 text-center mb-8">Sign in to manage product development</p>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Email</label>
            <input 
              type="email" 
              value={email} 
              onChange={e => setEmail(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Password</label>
            <input 
              type="password" 
              value={password} 
              onChange={e => setPassword(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
              required
            />
          </div>
          {error && <p className="text-red-500 text-sm">{error}</p>}
          <button 
            type="submit"
            className="w-full bg-indigo-600 text-white py-3 rounded-xl font-medium hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-600/20"
          >
            Sign In
          </button>
        </form>
      </motion.div>
    </div>
  );
};

const RoleSummary = ({ user, projects, stages }: { user: User, projects: Project[], stages: StageTemplate[] }) => {
  const stats = {
    totalProjects: projects.length,
    activeProjects: projects.filter(p => p.status === 'ACTIVE').length,
    pendingApproval: projects.filter(p => p.status === 'PENDING_PMO').length,
    submitted: projects.filter(p => p.status === 'SUBMITTED').length,
    completed: projects.filter(p => p.status === 'COMPLETED').length,
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
      <div className="bg-white p-6 rounded-3xl border border-black/5 shadow-sm">
        <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Total Projects</p>
        <p className="text-3xl font-serif font-medium text-indigo-600">{stats.totalProjects}</p>
      </div>
      <div className="bg-white p-6 rounded-3xl border border-black/5 shadow-sm">
        <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Active</p>
        <p className="text-3xl font-serif font-medium text-emerald-600">{stats.activeProjects}</p>
      </div>
      {user.role === 'PMO' || user.role === 'ADMIN' ? (
        <>
          <div className="bg-white p-6 rounded-3xl border border-black/5 shadow-sm">
            <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Pending Approval</p>
            <p className="text-3xl font-serif font-medium text-amber-600">{stats.pendingApproval}</p>
          </div>
          <div className="bg-white p-6 rounded-3xl border border-black/5 shadow-sm">
            <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Submitted for Eval</p>
            <p className="text-3xl font-serif font-medium text-blue-600">{stats.submitted}</p>
          </div>
        </>
      ) : (
        <>
          <div className="bg-white p-6 rounded-3xl border border-black/5 shadow-sm">
            <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">My Submitted</p>
            <p className="text-3xl font-serif font-medium text-blue-600">{stats.submitted}</p>
          </div>
          <div className="bg-white p-6 rounded-3xl border border-black/5 shadow-sm">
            <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Completed</p>
            <p className="text-3xl font-serif font-medium text-slate-600">{stats.completed}</p>
          </div>
        </>
      )}
    </div>
  );
};

const Dashboard = ({ user, onLogout }: { user: User, onLogout: () => void }) => {
  const [projects, setProjects] = useState<Project[]>([]);
  const [stages, setStages] = useState<StageTemplate[]>([]);
  const [activeTab, setActiveTab] = useState('projects');
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const [pRes, sRes] = await Promise.all([
      fetchWithAuth(`${API_URL}/projects`),
      fetchWithAuth(`${API_URL}/stages-template`)
    ]);
    setProjects(await pRes.json());
    setStages(await sRes.json());
  };

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Sidebar */}
      <div className="w-64 bg-white border-r border-black/5 flex flex-col p-6 shadow-sm">
        <div className="flex items-center gap-3 mb-10">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-600/20">
            <ClipboardList size={20} />
          </div>
          <span className="font-serif font-medium text-xl tracking-tight">NPD Tracker</span>
        </div>

        <nav className="flex-1 space-y-2">
          <SidebarItem 
            icon={<LayoutDashboard size={20} />} 
            label="Projects" 
            active={activeTab === 'projects'} 
            onClick={() => { setActiveTab('projects'); setSelectedProject(null); }} 
          />
          {user.role === 'ADMIN' && (
            <>
              <SidebarItem 
                icon={<Users size={20} />} 
                label="Users" 
                active={activeTab === 'users'} 
                onClick={() => setActiveTab('users')} 
              />
              <SidebarItem 
                icon={<Settings size={20} />} 
                label="Stages" 
                active={activeTab === 'stages'} 
                onClick={() => setActiveTab('stages')} 
              />
              <SidebarItem 
                icon={<History size={20} />} 
                label="Logs" 
                active={activeTab === 'logs'} 
                onClick={() => setActiveTab('logs')} 
              />
            </>
          )}
        </nav>

        <div className="mt-auto pt-6 border-t border-black/5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center text-gray-600 font-medium">
              {user.name[0]}
            </div>
            <div className="flex-1 overflow-hidden">
              <p className="text-sm font-medium truncate">{user.name}</p>
              <p className="text-xs text-gray-500">{user.role}</p>
            </div>
          </div>
          <button 
            onClick={onLogout}
            className="flex items-center gap-2 text-gray-500 hover:text-red-600 transition-colors text-sm font-medium"
          >
            <LogOut size={18} />
            Sign Out
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-10 overflow-auto">
        <AnimatePresence mode="wait">
          {selectedProject ? (
            <ProjectDetails 
              projectId={selectedProject.id} 
              user={user} 
              stages={stages} 
              onBack={() => { setSelectedProject(null); loadData(); }} 
            />
          ) : (
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              {activeTab === 'projects' && (
                <>
                  <RoleSummary user={user} projects={projects} stages={stages} />
                  <ProjectsList user={user} projects={projects} onSelect={setSelectedProject} onRefresh={loadData} />
                </>
              )}
              {activeTab === 'users' && <UsersManager currentUser={user} />}
              {activeTab === 'stages' && <StagesManager stages={stages} onRefresh={loadData} />}
              {activeTab === 'logs' && <LogsViewer />}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

const SidebarItem = ({ icon, label, active, onClick }: any) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
      active ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20' : 'text-slate-500 hover:bg-slate-50'
    }`}
  >
    {icon}
    <span className="font-medium">{label}</span>
  </button>
);

const ProjectsList = ({ user, projects, onSelect, onRefresh }: any) => {
  const [showCreate, setShowCreate] = useState(false);
  const [pls, setPls] = useState<User[]>([]);
  const [newName, setNewName] = useState('');
  const [selectedPl, setSelectedPl] = useState('');
  const [allTasks, setAllTasks] = useState<TaskData[]>([]);

  useEffect(() => {
    if (user.role === 'PMO' || user.role === 'ADMIN') {
      fetchWithAuth(`${API_URL}/users`).then(res => res.json()).then(data => {
        if (Array.isArray(data)) {
          setPls(data.filter((u: User) => u.role === 'PL'));
        }
      });
    }
    // Load all tasks to check for alerts
    const loadTasks = async () => {
      const tasksPromises = projects.map((p: Project) => fetchWithAuth(`${API_URL}/projects/${p.id}/tasks`).then(r => r.json()));
      const tasksResults = await Promise.all(tasksPromises);
      setAllTasks(tasksResults.flat());
    };
    if (projects.length > 0) loadTasks();
  }, [user.role, projects]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    const body: any = { name: newName };
    if (user.role === 'PMO') {
      body.pl_id = parseInt(selectedPl);
    }
    
    await fetchWithAuth(`${API_URL}/projects`, {
      method: 'POST',
      body: JSON.stringify(body),
    });
    setShowCreate(false);
    setNewName('');
    setSelectedPl('');
    onRefresh();
  };

  const handleApprove = async (id: number) => {
    await fetchWithAuth(`${API_URL}/projects/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status: 'ACTIVE' }),
    });
    onRefresh();
  };

  const handleExport = () => {
    const ws = XLSX.utils.json_to_sheet(projects.map((p: Project) => ({
      ID: p.id,
      Name: p.name,
      PL: p.pl_name,
      Stage: p.current_stage,
      Status: p.status
    })));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Projects");
    XLSX.writeFile(wb, "NPD_Projects.xlsx");
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-3xl font-serif font-medium text-slate-900">Projects</h2>
          <p className="text-slate-500">Manage and track product development lifecycle</p>
        </div>
        <div className="flex items-center gap-4">
          <button 
            onClick={handleExport}
            className="p-3 bg-white border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 transition-all shadow-sm"
            title="Export to Excel"
          >
            <Download size={20} />
          </button>
          <button 
            onClick={onRefresh}
            className="p-3 bg-white border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 transition-all shadow-sm"
            title="Refresh Projects"
          >
            <RefreshCw size={20} />
          </button>
          {(user.role === 'PMO' || user.role === 'PL') && (
            <button 
              onClick={() => setShowCreate(true)}
              className="flex items-center gap-2 bg-indigo-600 text-white px-6 py-3 rounded-xl font-medium hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-600/20"
            >
              <PlusCircle size={20} />
              New Project
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {projects.map((p: Project) => {
          const projectTasks = allTasks.filter(t => t.project_id === p.id && t.stage_num === p.current_stage);
          const hasAlert = projectTasks.some(t => t.alert_date && isBefore(new Date(t.alert_date), startOfDay(new Date())));

          return (
            <motion.div 
              key={p.id}
              whileHover={{ y: -5 }}
              className={`bg-white p-6 rounded-3xl border transition-all cursor-pointer ${
                hasAlert ? 'border-red-200 shadow-red-100 shadow-lg' : 'border-black/5 shadow-sm hover:shadow-md'
              }`}
              onClick={() => onSelect(p)}
            >
              <div className="flex justify-between items-start mb-4">
                <div className="flex gap-2">
                  <div className={`px-3 py-1 rounded-full text-xs font-medium ${
                    p.status === 'ACTIVE' ? 'bg-indigo-50 text-indigo-700' : 
                    p.status === 'COMPLETED' ? 'bg-blue-50 text-blue-700' : 'bg-amber-50 text-amber-700'
                  }`}>
                    {p.status}
                  </div>
                  {hasAlert && (
                    <div className="bg-red-500 text-white px-2 py-1 rounded-full text-[10px] font-bold flex items-center gap-1">
                      <AlertCircle size={10} /> ALERT
                    </div>
                  )}
                </div>
                <span className="text-xs text-gray-400">ID: {p.id}</span>
              </div>
              <h3 className="text-xl font-medium mb-2">{p.name}</h3>
              <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
                <Users size={14} />
                <span>PL: {p.pl_name}</span>
              </div>
              <div className="flex items-center justify-between pt-4 border-t border-black/5">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center text-gray-600 text-xs font-bold">
                    S{p.current_stage}
                  </div>
                  <span className="text-sm font-medium">Stage {p.current_stage}</span>
                </div>
                {user.role === 'PMO' && p.status === 'PENDING_PMO' && (
                  <button 
                    onClick={(e) => { e.stopPropagation(); handleApprove(p.id); }}
                    className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-indigo-700"
                  >
                    Approve
                  </button>
                )}
              </div>
            </motion.div>
          );
        })}
      </div>

      {showCreate && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
          <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="bg-white p-8 rounded-3xl w-full max-w-md">
            <h3 className="text-2xl font-serif font-medium mb-6">Create New Project</h3>
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Project Name</label>
                <input value={newName} onChange={e => setNewName(e.target.value)} className="w-full px-4 py-2 border rounded-xl" required />
              </div>
              {user.role === 'PMO' && (
                <div>
                  <label className="block text-sm font-medium mb-1">Assign Project Lead</label>
                  <select value={selectedPl} onChange={e => setSelectedPl(e.target.value)} className="w-full px-4 py-2 border rounded-xl" required>
                    <option value="">Select a PL</option>
                    {pls.map(pl => <option key={pl.id} value={pl.id}>{pl.name}</option>)}
                  </select>
                </div>
              )}
              {user.role === 'PL' && (
                <p className="text-sm text-gray-500 italic">This project will be assigned to you and will require PMO approval to start.</p>
              )}
              <div className="flex gap-4 pt-4">
                <button type="button" onClick={() => setShowCreate(false)} className="flex-1 py-2 border rounded-xl font-medium">Cancel</button>
                <button type="submit" className="flex-1 py-2 bg-indigo-600 text-white rounded-xl font-medium">Create</button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  );
};

const ProjectDetails = ({ projectId, user, stages, onBack }: { projectId: number, user: User, stages: StageTemplate[], onBack: () => void }) => {
  const [project, setProject] = useState<Project | null>(null);
  const [tasks, setTasks] = useState<TaskData[]>([]);
  const [docs, setDocs] = useState<DocType[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadProjectData();
  }, [projectId]);

  const loadProjectData = async () => {
    const [pRes, tRes, dRes] = await Promise.all([
      fetchWithAuth(`${API_URL}/projects`), // We fetch all and find ours to get latest status
      fetchWithAuth(`${API_URL}/projects/${projectId}/tasks`),
      fetchWithAuth(`${API_URL}/projects/${projectId}/documents`)
    ]);
    const allProjects = await pRes.json();
    const currentProject = allProjects.find((p: Project) => p.id === projectId);
    setProject(currentProject);
    setTasks(await tRes.json());
    setDocs(await dRes.json());
    setLoading(false);
  };

  const currentStageTemplate = stages.find((s: StageTemplate) => s.stage_number === project?.current_stage);

  const updateTask = async (taskId: string, updates: any) => {
    if (!project) return;
    await fetchWithAuth(`${API_URL}/projects/${project.id}/tasks`, {
      method: 'POST',
      body: JSON.stringify({
        stage_num: project.current_stage,
        task_id: taskId,
        ...updates
      }),
    });
    loadProjectData();
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, taskId?: string) => {
    if (!e.target.files?.[0] || !project) return;
    const file = e.target.files[0];
    const formData = new FormData();
    formData.append('file', file);
    formData.append('stage_num', project.current_stage.toString());
    if (taskId) formData.append('task_id', taskId);
    
    try {
      const res = await fetchWithAuth(`${API_URL}/projects/${project.id}/documents`, {
        method: 'POST',
        body: formData,
      });
      if (!res.ok) {
        const data = await res.json();
        alert(data.error || 'Upload failed');
      }
      loadProjectData();
    } catch (err) {
      alert('Upload failed. Please check file size and type.');
    } finally {
      e.target.value = ''; // Clear input to allow re-uploading same file
    }
  };

  const handleEvaluate = async (conform: boolean) => {
    if (!project) return;
    await fetchWithAuth(`${API_URL}/projects/${project.id}/evaluate`, {
      method: 'POST',
      body: JSON.stringify({ conform }),
    });
    loadProjectData(); // Refresh instead of going back to show the new stage
  };

  const handleSubmitForEvaluation = async () => {
    if (!project) return;
    await fetchWithAuth(`${API_URL}/projects/${project.id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status: 'SUBMITTED' }),
    });
    loadProjectData();
  };

  const isStageComplete = currentStageTemplate?.checklist.every(item => 
    tasks.find(t => t.task_id === item.id && t.stage_num === project?.current_stage)?.status === 'DONE'
  );

  if (loading || !project) return <div className="p-10 text-center font-serif">Loading project details...</div>;

  return (
    <div>
      <button onClick={onBack} className="flex items-center gap-2 text-gray-500 hover:text-black mb-6 transition-colors">
        <ChevronRight className="rotate-180" size={20} />
        Back to Projects
      </button>

      <div className="bg-white p-8 rounded-3xl border border-black/5 shadow-sm mb-8">
        <div className="flex justify-between items-start mb-8">
          <div>
            <h2 className="text-4xl font-serif font-medium mb-2">{project.name}</h2>
            <div className="flex items-center gap-4 text-gray-500">
              <span className="flex items-center gap-1"><Users size={16} /> {project.pl_name}</span>
              <span className="flex items-center gap-1"><ClipboardList size={16} /> Stage {project.current_stage}: {currentStageTemplate?.stage_name}</span>
            </div>
          </div>
          <div className={`px-4 py-2 rounded-full text-sm font-medium ${
            project.status === 'ACTIVE' ? 'bg-indigo-50 text-indigo-700' : 
            project.status === 'SUBMITTED' ? 'bg-amber-50 text-amber-700' :
            project.status === 'COMPLETED' ? 'bg-blue-50 text-blue-700' : 'bg-slate-50 text-slate-700'
          }`}>
            {project.status.replace('_', ' ')}
          </div>
        </div>

        {/* Stage Progress Bar */}
        <div className="flex gap-2 mb-10">
          {stages.map((s: StageTemplate) => (
            <div key={s.id} className="flex-1 h-2 rounded-full overflow-hidden bg-slate-100">
              <div className={`h-full transition-all duration-500 ${
                s.stage_number < project.current_stage ? 'bg-indigo-500' : 
                s.stage_number === project.current_stage ? 'bg-indigo-300' : 'bg-slate-200'
              }`} />
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          {/* Tasks List */}
          <div className="lg:col-span-2 space-y-6">
            <h3 className="text-xl font-medium flex items-center gap-2">
              <CheckCircle2 className="text-indigo-500" />
              Stage Checklist
            </h3>
            <div className="space-y-4">
              {currentStageTemplate?.checklist.map(item => {
                const task = tasks.find(t => t.task_id === item.id && t.stage_num === project.current_stage);
                const isAlert = task?.alert_date && isBefore(new Date(task.alert_date), startOfDay(new Date()));
                
                return (
                  <div key={item.id} className={`p-6 rounded-2xl border transition-all ${isAlert ? 'border-red-200 bg-red-50/30' : 'border-slate-100 bg-slate-50/30'}`}>
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <span className="font-medium text-slate-900">{item.label}</span>
                        {user.role === 'PL' && project.status === 'ACTIVE' && (
                          <label className="p-1.5 bg-white border rounded-lg text-gray-400 hover:text-indigo-600 cursor-pointer transition-colors shadow-sm" title="Upload document for this task">
                            <Upload size={14} />
                            <input type="file" className="hidden" onChange={(e) => handleFileUpload(e, item.id)} />
                          </label>
                        )}
                      </div>
                      <select 
                        disabled={user.role !== 'PL' || (project.status !== 'ACTIVE' && project.status !== 'SUBMITTED')}
                        value={task?.status || 'NOT_STARTED'}
                        onChange={e => {
                          const newStatus = e.target.value;
                          const updates: any = { status: newStatus };
                          updateTask(item.id, updates);
                        }}
                        className="px-3 py-1 rounded-lg border text-sm outline-none"
                      >
                        <option value="NOT_STARTED">Not Started</option>
                        <option value="STARTED">Started</option>
                        <option value="IN_TRANSIT">In Transit</option>
                        <option value="DONE">Done</option>
                      </select>
                    </div>
                    <div className="flex flex-wrap gap-4 items-center">
                      <input 
                        disabled={user.role !== 'PL' || (project.status !== 'ACTIVE' && project.status !== 'SUBMITTED')}
                        placeholder="Remarks..."
                        value={task?.remarks || ''}
                        onChange={e => updateTask(item.id, { remarks: e.target.value })}
                        className="flex-1 min-w-[200px] px-3 py-2 rounded-lg border text-sm bg-white"
                      />
                      <div className="flex items-center gap-2 bg-white border rounded-lg px-3 py-2">
                        <Calendar size={14} className="text-gray-400" />
                        <input 
                          disabled={user.role !== 'PL' || (project.status !== 'ACTIVE' && project.status !== 'SUBMITTED')}
                          type="date"
                          min={new Date().toISOString().split('T')[0]}
                          value={task?.alert_date || ''}
                          onChange={e => updateTask(item.id, { alert_date: e.target.value })}
                          className="text-xs outline-none"
                        />
                      </div>
                      <input 
                        disabled={user.role !== 'PL' || (project.status !== 'ACTIVE' && project.status !== 'SUBMITTED')}
                        placeholder="Alert comment..."
                        value={task?.alert_comment || ''}
                        onChange={e => updateTask(item.id, { alert_comment: e.target.value })}
                        className="flex-1 min-w-[150px] px-3 py-2 rounded-lg border text-sm bg-white"
                      />
                      {isAlert && <AlertCircle className="text-red-500" size={20} />}
                    </div>
                    {/* Task specific documents */}
                    {docs.filter(d => d.task_id === item.id).length > 0 && (
                      <div className="mt-4 flex flex-wrap gap-2">
                        {docs.filter(d => d.task_id === item.id).map(d => (
                          <a 
                            key={d.id} 
                            href={`/api/documents/${d.file_path}`} 
                            target="_blank" 
                            className="text-[10px] bg-white border px-2 py-1 rounded flex items-center gap-1 text-gray-500 hover:text-indigo-600"
                          >
                            <FileText size={10} /> {d.file_path.split('-').slice(1).join('-')}
                          </a>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Documents & Actions */}
          <div className="space-y-8">
            <div className="bg-gray-50 p-6 rounded-2xl border border-gray-100">
              <h3 className="text-lg font-medium mb-4 flex items-center gap-2">
                <FileText className="text-blue-500" />
                Documents
              </h3>
              <div className="space-y-3 mb-6">
                {docs.filter(d => d.stage_num === project.current_stage && !d.task_id).map(doc => (
                  <a 
                    key={doc.id}
                    href={`/api/documents/${doc.file_path}`}
                    target="_blank"
                    className="flex items-center justify-between p-3 bg-white rounded-xl border border-gray-100 hover:border-blue-200 transition-all group"
                  >
                    <span className="text-sm truncate flex-1">{doc.file_path.split('-').slice(1).join('-')}</span>
                    <Download size={16} className="text-gray-400 group-hover:text-blue-500" />
                  </a>
                ))}
              </div>
              {user.role === 'PL' && (project.status === 'ACTIVE' || project.status === 'SUBMITTED') && (
                <label className="flex flex-col items-center justify-center p-6 border-2 border-dashed border-gray-200 rounded-xl cursor-pointer hover:border-indigo-300 transition-all bg-white group">
                  <Upload className="text-gray-400 group-hover:text-indigo-500 mb-2" />
                  <span className="text-xs text-gray-500">Click to upload doc</span>
                  <input type="file" className="hidden" onChange={handleFileUpload} />
                </label>
              )}
            </div>

            {user.role === 'PMO' && project.status === 'SUBMITTED' && (
              <div className="bg-indigo-50 p-6 rounded-2xl border border-indigo-100">
                <h3 className="text-lg font-medium mb-4 text-indigo-900">PMO Evaluation</h3>
                <p className="text-sm text-indigo-700 mb-6">Review all tasks and documents before making a decision.</p>
                <div className="flex gap-3">
                  <button 
                    onClick={() => handleEvaluate(false)}
                    className="flex-1 flex items-center justify-center gap-2 bg-white text-red-600 border border-red-100 py-3 rounded-xl font-medium hover:bg-red-50 transition-all"
                  >
                    <X size={18} /> Non-Conform
                  </button>
                  <button 
                    onClick={() => handleEvaluate(true)}
                    className="flex-1 flex items-center justify-center gap-2 bg-indigo-600 text-white py-3 rounded-xl font-medium hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-600/20"
                  >
                    <Check size={18} /> Conform
                  </button>
                </div>
              </div>
            )}

            {user.role === 'PMO' && project.status === 'ACTIVE' && (
              <div className="bg-blue-50 p-6 rounded-2xl border border-blue-100">
                <h3 className="text-lg font-medium mb-2 text-blue-800">View Only</h3>
                <p className="text-sm text-blue-600">This project is currently being worked on by the PL. You will be able to evaluate once it is submitted.</p>
              </div>
            )}

            {user.role === 'PL' && project.status === 'ACTIVE' && isStageComplete && (
              <div className="bg-indigo-600 p-6 rounded-2xl text-white shadow-xl shadow-indigo-600/20">
                <h3 className="text-lg font-medium mb-2">Stage Complete</h3>
                <p className="text-sm opacity-90 mb-6">All tasks are marked as Done. You can now notify PMO for evaluation.</p>
                <button 
                  onClick={handleSubmitForEvaluation}
                  className="w-full bg-white text-indigo-700 py-3 rounded-xl font-bold hover:bg-indigo-50 transition-all"
                >
                  Submit for Evaluation
                </button>
              </div>
            )}
            
            {project.status === 'SUBMITTED' && user.role === 'PL' && (
              <div className="bg-amber-50 p-6 rounded-2xl border border-amber-100">
                <h3 className="text-lg font-medium mb-2 text-amber-800">Submitted</h3>
                <p className="text-sm text-amber-600">Waiting for PMO evaluation. You cannot make changes at this time.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const UsersManager = ({ currentUser }: { currentUser: User }) => {
  const [users, setUsers] = useState<User[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [formData, setFormData] = useState({ email: '', name: '', password: '', role: 'PL' });

  useEffect(() => { loadUsers(); }, []);

  const loadUsers = async () => {
    const res = await fetchWithAuth(`${API_URL}/users`);
    setUsers(await res.json());
  };

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    await fetchWithAuth(`${API_URL}/users`, {
      method: 'POST',
      body: JSON.stringify(formData),
    });
    setShowAdd(false);
    setFormData({ email: '', name: '', password: '', role: 'PL' });
    loadUsers();
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Are you sure you want to delete this user?')) return;
    const res = await fetchWithAuth(`${API_URL}/users/${id}`, { method: 'DELETE' });
    if (res.ok) loadUsers();
    else {
      const data = await res.json();
      alert(data.error || 'Failed to delete user');
    }
  };

  const handleExport = () => {
    const ws = XLSX.utils.json_to_sheet(users.map(u => ({
      Name: u.name,
      Email: u.email,
      Role: u.role
    })));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Users");
    XLSX.writeFile(wb, "NPD_Users.xlsx");
  };

  const handleBulkImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (evt) => {
      const bstr = evt.target?.result;
      const wb = XLSX.read(bstr, { type: 'binary' });
      const ws = wb.Sheets[wb.SheetNames[0]];
      const data = XLSX.utils.sheet_to_json(ws) as any[];
      
      const usersToImport = data.map(row => ({
        name: row.Name || row.name,
        email: row.Email || row.email,
        role: row.Role || row.role || 'PL',
        password: row.Password || row.password || 'user123'
      })).filter(u => u.email && u.name);

      const res = await fetchWithAuth(`${API_URL}/users/bulk`, {
        method: 'POST',
        body: JSON.stringify(usersToImport),
      });
      if (res.ok) {
        const result = await res.json();
        alert(`Successfully imported ${result.count} users.`);
        loadUsers();
      } else {
        alert('Bulk import failed.');
      }
      e.target.value = '';
    };
    reader.readAsBinaryString(file);
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-3xl font-serif font-medium text-slate-900">User Management</h2>
          <p className="text-slate-500">Manage system access and roles</p>
        </div>
        <div className="flex items-center gap-4">
          <button 
            onClick={handleExport}
            className="p-3 bg-white border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 transition-all shadow-sm"
            title="Export to Excel"
          >
            <Download size={20} />
          </button>
          <label className="p-3 bg-white border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 transition-all shadow-sm cursor-pointer" title="Bulk Import Users">
            <FileSpreadsheet size={20} />
            <input type="file" className="hidden" accept=".xlsx,.xls,.csv" onChange={handleBulkImport} />
          </label>
          <button 
            onClick={loadUsers}
            className="p-3 bg-white border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 transition-all shadow-sm"
            title="Refresh Users"
          >
            <RefreshCw size={20} />
          </button>
          <button 
            onClick={() => setShowAdd(true)} 
            className="bg-indigo-600 text-white px-6 py-3 rounded-xl font-medium flex items-center gap-2 hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-600/20"
          >
            <UserPlus size={20} /> Add User
          </button>
        </div>
      </div>

      <div className="bg-white rounded-3xl border border-black/5 overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-gray-50 border-bottom border-black/5">
            <tr>
              <th className="px-6 py-4 text-sm font-medium text-gray-500">Name</th>
              <th className="px-6 py-4 text-sm font-medium text-gray-500">Email</th>
              <th className="px-6 py-4 text-sm font-medium text-gray-500">Role</th>
              <th className="px-6 py-4 text-sm font-medium text-gray-500 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-black/5">
            {users.map(u => (
              <tr key={u.id} className="hover:bg-gray-50 transition-colors">
                <td className="px-6 py-4 font-medium">{u.name}</td>
                <td className="px-6 py-4 text-gray-500">{u.email}</td>
                <td className="px-6 py-4">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                    u.role === 'ADMIN' ? 'bg-purple-50 text-purple-700' :
                    u.role === 'PMO' ? 'bg-blue-50 text-blue-700' : 'bg-indigo-50 text-indigo-700'
                  }`}>
                    {u.role}
                  </span>
                </td>
                <td className="px-6 py-4 text-right">
                  {u.id !== currentUser.id && (
                    <button 
                      onClick={() => handleDelete(u.id)}
                      className="text-red-500 hover:text-red-700 transition-colors p-1"
                    >
                      <X size={18} />
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showAdd && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
          <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="bg-white p-8 rounded-3xl w-full max-w-md">
            <h3 className="text-2xl font-serif font-medium mb-6">Add New User</h3>
            <form onSubmit={handleAdd} className="space-y-4">
              <input placeholder="Name" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full px-4 py-2 border rounded-xl" required />
              <input type="email" placeholder="Email" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} className="w-full px-4 py-2 border rounded-xl" required />
              <input type="password" placeholder="Password" value={formData.password} onChange={e => setFormData({...formData, password: e.target.value})} className="w-full px-4 py-2 border rounded-xl" required />
              <select value={formData.role} onChange={e => setFormData({...formData, role: e.target.value})} className="w-full px-4 py-2 border rounded-xl">
                <option value="PL">Project Lead (PL)</option>
                <option value="PMO">PMO</option>
                <option value="ADMIN">Admin</option>
              </select>
              <div className="flex gap-4 pt-4">
                <button type="button" onClick={() => setShowAdd(false)} className="flex-1 py-2 border rounded-xl">Cancel</button>
                <button type="submit" className="flex-1 py-2 bg-indigo-600 text-white rounded-xl">Add User</button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  );
};

const StagesManager = ({ stages, onRefresh }: any) => {
  const [editing, setEditing] = useState<StageTemplate | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [newStage, setNewStage] = useState({ stage_name: '', checklist: [] as { id: string; label: string }[] });

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editing) return;
    await fetchWithAuth(`${API_URL}/stages-template/${editing.id}`, {
      method: 'PUT',
      body: JSON.stringify(editing),
    });
    setEditing(null);
    onRefresh();
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    await fetchWithAuth(`${API_URL}/stages-template`, {
      method: 'POST',
      body: JSON.stringify(newStage),
    });
    setShowAdd(false);
    setNewStage({ stage_name: '', checklist: [] });
    onRefresh();
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Are you sure you want to delete this stage?')) return;
    const res = await fetchWithAuth(`${API_URL}/stages-template/${id}`, {
      method: 'DELETE',
    });
    if (res.ok) {
      onRefresh();
    } else {
      const data = await res.json();
      alert(data.error || 'Failed to delete stage');
    }
  };

  const handleBulkImport = (e: React.ChangeEvent<HTMLInputElement>, isEditing: boolean) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      const bstr = evt.target?.result;
      const wb = XLSX.read(bstr, { type: 'binary' });
      const wsname = wb.SheetNames[0];
      const ws = wb.Sheets[wsname];
      const data = XLSX.utils.sheet_to_json(ws, { header: 1 }) as any[][];
      
      // Assume first column is the task label
      const importedChecklist = data
        .filter(row => row[0] && row[0].toString().trim() !== '')
        .map(row => ({
          id: Math.random().toString(36).substr(2, 9),
          label: row[0].toString().trim()
        }));

      if (isEditing && editing) {
        setEditing({ ...editing, checklist: [...editing.checklist, ...importedChecklist] });
      } else {
        setNewStage({ ...newStage, checklist: [...newStage.checklist, ...importedChecklist] });
      }
      e.target.value = '';
    };
    reader.readAsBinaryString(file);
  };

  const handleBulkImportStages = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (evt) => {
      const bstr = evt.target?.result;
      const wb = XLSX.read(bstr, { type: 'binary' });
      const ws = wb.Sheets[wb.SheetNames[0]];
      const data = XLSX.utils.sheet_to_json(ws) as any[];
      
      // Group by stage name
      const stagesMap: Record<string, any[]> = {};
      data.forEach(row => {
        const stageName = row.StageName || row.stage_name;
        const taskLabel = row.TaskLabel || row.task_label;
        if (stageName && taskLabel) {
          if (!stagesMap[stageName]) stagesMap[stageName] = [];
          stagesMap[stageName].push({ id: Math.random().toString(36).substr(2, 9), label: taskLabel });
        }
      });

      const stagesToImport = Object.keys(stagesMap).map(name => ({
        stage_name: name,
        checklist: stagesMap[name]
      }));

      const res = await fetchWithAuth(`${API_URL}/stages-template/bulk`, {
        method: 'POST',
        body: JSON.stringify(stagesToImport),
      });
      if (res.ok) {
        alert('Successfully imported stages.');
        onRefresh();
      } else {
        alert('Bulk import failed.');
      }
      e.target.value = '';
    };
    reader.readAsBinaryString(file);
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-3xl font-serif font-medium text-slate-900">Stage Templates</h2>
        <div className="flex items-center gap-4">
          <label className="p-3 bg-white border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 transition-all shadow-sm cursor-pointer" title="Bulk Import Stages">
            <FileSpreadsheet size={20} />
            <input type="file" className="hidden" accept=".xlsx,.xls,.csv" onChange={handleBulkImportStages} />
          </label>
          <button 
            onClick={() => setShowAdd(true)}
            className="bg-indigo-600 text-white px-6 py-3 rounded-xl font-medium flex items-center gap-2 hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-600/20"
          >
            <PlusCircle size={20} /> New Stage
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {stages.map((s: StageTemplate) => (
          <div key={s.id} className="bg-white p-6 rounded-3xl border border-black/5 shadow-sm group hover:shadow-md transition-all">
            <div className="flex justify-between items-center mb-4">
              <span className="text-xs font-bold text-indigo-600 uppercase tracking-widest">Stage {s.stage_number}</span>
              <div className="flex gap-2">
                <button onClick={() => setEditing(s)} className="text-gray-400 hover:text-indigo-600 transition-colors p-1">
                  <Settings size={18} />
                </button>
                <button onClick={() => handleDelete(s.id)} className="text-gray-400 hover:text-red-600 transition-colors p-1">
                  <X size={18} />
                </button>
              </div>
            </div>
            <h3 className="text-xl font-medium mb-4">{s.stage_name}</h3>
            <div className="space-y-2">
              {s.checklist.map(item => (
                <div key={item.id} className="flex items-center gap-2 text-sm text-gray-500">
                  <CheckCircle2 size={14} className="text-indigo-500" />
                  {item.label}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Add Stage Modal */}
      {showAdd && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
          <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="bg-white p-8 rounded-3xl w-full max-w-2xl max-h-[80vh] overflow-auto">
            <h3 className="text-2xl font-serif font-medium mb-6">Add New Stage</h3>
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Stage Name</label>
                <input 
                  value={newStage.stage_name} 
                  onChange={e => setNewStage({...newStage, stage_name: e.target.value})} 
                  className="w-full px-4 py-2 border rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" 
                  placeholder="e.g. Quality Assurance"
                  required
                />
              </div>
              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="block text-sm font-medium">Checklist Items</label>
                  <label className="text-xs text-indigo-600 hover:text-indigo-700 cursor-pointer flex items-center gap-1 font-medium">
                    <FileSpreadsheet size={14} />
                    Bulk Import (Excel/CSV)
                    <input type="file" className="hidden" accept=".xlsx,.xls,.csv" onChange={(e) => handleBulkImport(e, false)} />
                  </label>
                </div>
                {newStage.checklist.map((item, idx) => (
                  <div key={idx} className="flex gap-2 mb-2">
                    <input 
                      value={item.label} 
                      onChange={e => {
                        const newChecklist = [...newStage.checklist];
                        newChecklist[idx].label = e.target.value;
                        setNewStage({...newStage, checklist: newChecklist});
                      }}
                      className="flex-1 px-4 py-2 border rounded-xl"
                      placeholder="Task description"
                      required
                    />
                    <button 
                      type="button"
                      onClick={() => {
                        const newChecklist = newStage.checklist.filter((_, i) => i !== idx);
                        setNewStage({...newStage, checklist: newChecklist});
                      }}
                      className="p-2 text-red-500 hover:bg-red-50 rounded-lg"
                    >
                      <X size={20} />
                    </button>
                  </div>
                ))}
                <button 
                  type="button"
                  onClick={() => setNewStage({...newStage, checklist: [...newStage.checklist, { id: Math.random().toString(36).substr(2, 9), label: '' }]})}
                  className="w-full py-2 border-2 border-dashed rounded-xl text-gray-500 hover:border-indigo-300 hover:text-indigo-600 transition-all"
                >
                  + Add Item
                </button>
              </div>
              <div className="flex gap-4 pt-4">
                <button type="button" onClick={() => setShowAdd(false)} className="flex-1 py-2 border rounded-xl font-medium">Cancel</button>
                <button type="submit" className="flex-1 py-2 bg-indigo-600 text-white rounded-xl font-medium">Create Stage</button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {/* Edit Stage Modal */}
      {editing && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
          <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="bg-white p-8 rounded-3xl w-full max-w-2xl max-h-[80vh] overflow-auto">
            <h3 className="text-2xl font-serif font-medium mb-6">Edit Stage {editing.stage_number}</h3>
            <form onSubmit={handleUpdate} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Stage Name</label>
                <input value={editing.stage_name} onChange={e => setEditing({...editing, stage_name: e.target.value})} className="w-full px-4 py-2 border rounded-xl" />
              </div>
              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="block text-sm font-medium">Checklist Items</label>
                  <label className="text-xs text-indigo-600 hover:text-indigo-700 cursor-pointer flex items-center gap-1 font-medium">
                    <FileSpreadsheet size={14} />
                    Bulk Import (Excel/CSV)
                    <input type="file" className="hidden" accept=".xlsx,.xls,.csv" onChange={(e) => handleBulkImport(e, true)} />
                  </label>
                </div>
                {editing.checklist.map((item, idx) => (
                  <div key={item.id} className="flex gap-2 mb-2">
                    <input 
                      value={item.label} 
                      onChange={e => {
                        const newChecklist = [...editing.checklist];
                        newChecklist[idx].label = e.target.value;
                        setEditing({...editing, checklist: newChecklist});
                      }}
                      className="flex-1 px-4 py-2 border rounded-xl"
                    />
                    <button 
                      type="button"
                      onClick={() => {
                        const newChecklist = editing.checklist.filter((_, i) => i !== idx);
                        setEditing({...editing, checklist: newChecklist});
                      }}
                      className="p-2 text-red-500 hover:bg-red-50 rounded-lg"
                    >
                      <X size={20} />
                    </button>
                  </div>
                ))}
                <button 
                  type="button"
                  onClick={() => setEditing({...editing, checklist: [...editing.checklist, { id: Math.random().toString(36).substr(2, 9), label: '' }]})}
                  className="w-full py-2 border-2 border-dashed rounded-xl text-gray-500 hover:border-indigo-300 hover:text-indigo-600 transition-all"
                >
                  + Add Item
                </button>
              </div>
              <div className="flex gap-4 pt-4">
                <button type="button" onClick={() => setEditing(null)} className="flex-1 py-2 border rounded-xl">Cancel</button>
                <button type="submit" className="flex-1 py-2 bg-indigo-600 text-white rounded-xl">Save Changes</button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  );
};

const LogsViewer = () => {
  const [logs, setLogs] = useState<Log[]>([]);

  useEffect(() => { loadLogs(); }, []);

  const loadLogs = async () => {
    const res = await fetchWithAuth(`${API_URL}/logs`);
    setLogs(await res.json());
  };

  const handleReverse = async (id: number) => {
    const res = await fetchWithAuth(`${API_URL}/logs/${id}/reverse`, { method: 'POST' });
    if (res.ok) loadLogs();
    else alert('Failed to reverse');
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-3xl font-serif font-medium text-slate-900">System Logs</h2>
        <button 
          onClick={loadLogs}
          className="p-3 bg-white border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 transition-all shadow-sm"
          title="Refresh Logs"
        >
          <RefreshCw size={20} />
        </button>
      </div>
      <div className="bg-white rounded-3xl border border-black/5 overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-gray-50 border-bottom border-black/5">
            <tr>
              <th className="px-6 py-4 text-sm font-medium text-gray-500">Timestamp</th>
              <th className="px-6 py-4 text-sm font-medium text-gray-500">User</th>
              <th className="px-6 py-4 text-sm font-medium text-gray-500">Action</th>
              <th className="px-6 py-4 text-sm font-medium text-gray-500">Details</th>
              <th className="px-6 py-4 text-sm font-medium text-gray-500"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-black/5">
            {logs.map(l => (
              <tr key={l.id} className="hover:bg-gray-50 transition-colors">
                <td className="px-6 py-4 text-sm text-gray-500">{format(new Date(l.timestamp), 'MMM d, HH:mm')}</td>
                <td className="px-6 py-4 font-medium">{l.user_name}</td>
                <td className="px-6 py-4">
                  <span className="text-xs font-mono bg-gray-100 px-2 py-1 rounded uppercase">{l.action}</span>
                </td>
                <td className="px-6 py-4 text-sm text-gray-500">{l.details}</td>
                <td className="px-6 py-4 text-right">
                  {Number(l.reversible_flag) === 1 && (
                    <button 
                      onClick={() => handleReverse(l.id)}
                      className="text-xs text-indigo-600 font-bold hover:underline"
                    >
                      REVERSE
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default function App() {
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('user');
    return saved ? JSON.parse(saved) : null;
  });

  const handleLogin = (user: User, token: string) => {
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(user));
    setUser(user);
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setUser(null);
    window.location.reload();
  };

  if (!user) return <Login onLogin={handleLogin} />;

  return <Dashboard user={user} onLogout={handleLogout} />;
}

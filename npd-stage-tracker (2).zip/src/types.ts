import React, { createContext, useContext, useState, useEffect } from 'react';

export type Role = 'ADMIN' | 'PMO' | 'PL';

export interface User {
  id: number;
  email: string;
  name: string;
  role: Role;
}

export interface StageTemplate {
  id: number;
  stage_number: number;
  stage_name: string;
  checklist: { id: string; label: string }[];
}

export interface Project {
  id: number;
  name: string;
  pl_id: number;
  pl_name: string;
  current_stage: number;
  status: 'PENDING_PMO' | 'ACTIVE' | 'SUBMITTED' | 'COMPLETED';
}

export interface TaskData {
  id: number;
  project_id: number;
  stage_num: number;
  task_id: string;
  status: 'NOT_STARTED' | 'STARTED' | 'IN_TRANSIT' | 'DONE';
  remarks: string;
  alert_date: string;
  alert_comment: string;
}

export interface Document {
  id: number;
  project_id: number;
  stage_num: number;
  task_id: string | null;
  file_path: string;
  uploaded_by: number;
}

export interface Log {
  id: number;
  user_id: number;
  user_name: string;
  action: string;
  details: string;
  timestamp: string;
  reversible_flag: boolean;
}
